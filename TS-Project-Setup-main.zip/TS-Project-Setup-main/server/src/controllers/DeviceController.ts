import { IDevice } from "../models/deviceModel.js";
import {devices} from ".././data/devicesData.js";
import { Request, Response } from "express";

class DeviceController {
    private devices: IDevice[]=[];

    getAll(req: Request, res: Response) { 

        return res.status(200).json(devices)
    }
    getOne() {}
    create() {}
    update() {}
    delete() {}
    getTypes(req: Request, res: Response) {
        const types = devices.map((device) => device.type);
        const uniqueTypes=[...new Set(types)]
        res.json(uniqueTypes)
    }
    getBrands(req: Request, res: Response) {
        const brands = devices.map((device) => device.brand);
        const uniqueBrands = [...new Set(brands)]
        res.json(uniqueBrands)
    }
}

export default new DeviceController;


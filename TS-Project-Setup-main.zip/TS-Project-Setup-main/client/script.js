$(document).ready(function() {
$.ajax({
    "url": "http://localhost:5557/devices",
    "method": "GET",
    "dataType": "json",
    "timeout": 0,
  }).done(function (response) {
    console.log(response);
    const productContainer = $('.product-list');
    productContainer.empty();

    response.forEach((product) => {
        const productElement = `<div class="product">
    <h3>${product.name}</h3>
    <p>${product.brand} ${product.type}</p>
    <p>${product.type}</p>
    <p>${product.description}</p>
    </div>`;
   
    productContainer.append(productElement); 

    });
  });


const brandSelect = $('#brand');
const typeSelect = $('#type');

$.ajax({
    "url": "http://localhost:5558/devices/brands",
    "method": "GET",
    "dataType": "json",
    "timeout": 0,
  }).done(function (response) {
    console.log(response);

    response.forEach((brand) => {
    const brandOption = `<option value="${brand}">${brand}</option>`;
   
    brandSelect.append(brandOption); 

    });
  });

  $.ajax({
    "url": "http://localhost:5558/devices/types",
    "method": "GET",
    "dataType": "json",
    "timeout": 0,
  }).done(function (response) {
    console.log(response);

    response.forEach((type) => {
    const typeOption = `<option value="${type}">${type}</option>`;
   
    typeSelect.append(typeOption); 

    });
  });
});